"""Check the Vercel storage path against a disposable PostgreSQL database."""

import os
from concurrent.futures import ThreadPoolExecutor
from uuid import uuid4

import pytest
from psycopg import connect, sql
from psycopg.conninfo import make_conninfo

from app.core.config import Settings, load_settings
from app.repositories.postgres_repo import PostgresRepository

from .conftest import CSRF, free_slot, login, make_client


def test_hosted_vercel_requires_shared_storage(monkeypatch) -> None:
    monkeypatch.setenv("VERCEL_ENV", "production")
    monkeypatch.setenv("SESSION_SECRET", "x" * 48)
    monkeypatch.setenv("STORAGE_BACKEND", "memory")
    with pytest.raises(ValueError, match="require PostgreSQL"):
        load_settings()

    monkeypatch.setenv("STORAGE_BACKEND", "postgres")
    monkeypatch.setenv("DATABASE_URL", "postgresql://localhost/lablink")
    monkeypatch.setenv("AI_PROVIDER", "apikey")
    monkeypatch.setenv("AI_ENABLED", "false")
    settings = load_settings()
    assert settings.production and settings.storage == "postgres"
    assert settings.database_url not in repr(settings)


@pytest.fixture()
def isolated_database():
    url = os.getenv("LABLINK_TEST_DATABASE_URL")
    if not url:
        pytest.skip("Set LABLINK_TEST_DATABASE_URL to a disposable PostgreSQL database.")
    name = "lablink_test_" + uuid4().hex
    schema = sql.Identifier(name)
    with connect(url, autocommit=True) as connection:
        connection.execute(sql.SQL("CREATE SCHEMA {}").format(schema))
    try:
        yield make_conninfo(url, options=f"-c search_path={name}")
    finally:
        with connect(url, autocommit=True) as connection:
            connection.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(schema))


def test_bookings_are_shared_and_atomic_between_app_instances(isolated_database: str) -> None:
    settings = Settings(storage="postgres", database_url=isolated_database, ai_enabled=False)
    with make_client(settings=settings) as first, make_client(settings=settings) as second:
        login(first, "u-diya")
        login(second, "u-kabir")
        item = "eq-spectrum-rs"
        slot = free_slot(first, item)
        payload = {key: slot[key] for key in ("start", "end")}
        payload.update(equipment_id=item, purpose="Prototype measurements")

        def book(client):
            return client.post("/api/bookings", json=payload, headers=CSRF)

        with ThreadPoolExecutor(max_workers=2) as executor:
            responses = list(executor.map(book, [first, second]))
        assert sorted(result.status_code for result in responses) == [201, 409]
        confirmed = next(result.json() for result in responses if result.status_code == 201)

    snapshot = PostgresRepository(isolated_database).read()
    assert snapshot.bookings[confirmed["id"]].status == "confirmed"
