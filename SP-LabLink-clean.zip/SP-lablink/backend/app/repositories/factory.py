from ..core.config import Settings
from .base import Repository
from .firestore_repo import FirestoreRepository
from .memory_repo import InMemoryRepository
from .postgres_repo import PostgresRepository


def build_repository(settings: Settings) -> Repository:
    """Select the repository implementation for the configured storage mode."""
    if settings.storage == "firestore":
        return FirestoreRepository(settings.gcp_project, settings.firestore_database)
    if settings.storage == "postgres":
        return PostgresRepository(settings.database_url)
    return InMemoryRepository()
