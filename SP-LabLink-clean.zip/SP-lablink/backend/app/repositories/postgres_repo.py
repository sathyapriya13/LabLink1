from collections.abc import Callable
from threading import Lock

from psycopg import connect
from psycopg.types.json import Jsonb

from .base import State

SCHEMA_LOCK = 914053107


class PostgresRepository:
    """Persist one shared demo snapshot and serialize writes across instances."""

    def __init__(self, database_url: str) -> None:
        self._database_url = database_url
        self._initialized = False
        self._init_lock = Lock()

    def _connect(self):
        return connect(self._database_url, connect_timeout=5)

    def _ensure_storage(self) -> None:
        with self._init_lock:
            if self._initialized:
                return
            with self._connect() as connection:
                connection.execute("SELECT pg_advisory_xact_lock(%s)", (SCHEMA_LOCK,))
                connection.execute("""
                    CREATE TABLE IF NOT EXISTS lablink_state (
                        id integer PRIMARY KEY CHECK (id = 1),
                        payload jsonb NOT NULL
                    )
                """)
                connection.execute(
                    "INSERT INTO lablink_state (id, payload) VALUES (1, %s) ON CONFLICT (id) DO NOTHING",
                    (Jsonb(State().model_dump(mode="json")),),
                )
            self._initialized = True

    def read(self) -> State:
        """Return the latest committed snapshot."""
        self._ensure_storage()
        with self._connect() as connection:
            row = connection.execute("SELECT payload FROM lablink_state WHERE id = 1").fetchone()
        if row is None:
            raise RuntimeError("LabLink database state is missing")
        return State.model_validate(row[0])

    def transact[T](self, operation: Callable[[State], T]) -> T:
        """Lock the snapshot before validating and applying a state transition."""
        self._ensure_storage()
        with self._connect() as connection:
            row = connection.execute("SELECT payload FROM lablink_state WHERE id = 1 FOR UPDATE").fetchone()
            if row is None:
                raise RuntimeError("LabLink database state is missing")
            state = State.model_validate(row[0])
            result = operation(state)
            payload = state.model_dump(mode="json")
            if payload != row[0]:
                connection.execute("UPDATE lablink_state SET payload = %s WHERE id = 1", (Jsonb(payload),))
            return result
